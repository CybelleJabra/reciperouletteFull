const express = require('express');
const router = express.Router();
const {
    createRecipeController,
    getRecipesByCriteriaController,
    getRecipesByUserController,
    getRecipeDetailsController,
    searchRecipesController
} = require('../Controllers/recipes.controllers');
const { recipeValidation } = require('../validation/recipes.validators');

// Route for creating a recipe
router.post('/createRecipe', recipeValidation, createRecipeController);

// Route to get recipes by various criteria
router.get('/recipesByCriteria', recipeValidation, getRecipesByCriteriaController);

// Route to get recipes by user
router.get('/recipesByUser/:username', recipeValidation, getRecipesByUserController);

// Route to get recipe details by recipe ID
router.get('/recipedetails', getRecipeDetailsController);

// Route for searching recipes
router.get('/searchRecipes', searchRecipesController);

// Homepage Route
router.get('/', (req, res) => {
    res.render('homepage');
});

module.exports = router;
