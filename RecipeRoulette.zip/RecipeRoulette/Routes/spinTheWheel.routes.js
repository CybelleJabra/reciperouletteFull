const express = require('express');
const router = express.Router();
const { spinTheWheelController } = require('../Controllers/spinTheWheel.controller');
const { getCuisineIdByName } = require('../Services/cuisines.services');

// Fetching cuisine ID and rendering the spinning wheel page
router.post('/spinningwheel', async (req, res) => {
    const { dietaryPreferences, calories, cuisine } = req.body;

    try {
        const cuisineId = await getCuisineIdByName(cuisine);
        if (!cuisineId) {
            // in case of error, renders errorPage
            return res.status(400).render('errorPage', { message: "Cuisine not found" });
        }

        // renders spinningwheel with necessary information
        res.render('spinningwheel', {
            dietaryPreferences,
            calories,
            cuisine,
            cuisineId
        });
    } catch (error) {
        console.error("Error fetching cuisine ID:", error);
        // in case of error, renders errorPage
        res.status(500).render('errorPage', { message: "Error fetching cuisine ID" });
    }
});

// Delegating the spinning of the wheel to the controller
router.post('/spinTheWheel', spinTheWheelController);

// renders the taketoresults page
router.get('/taketoresults', (req, res) => {
    const { message, success, recipeId } = req.query;
    res.render('taketoresults', { message, success, recipeId });
});

module.exports = router;
