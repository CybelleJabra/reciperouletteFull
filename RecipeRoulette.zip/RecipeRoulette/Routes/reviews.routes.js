const express = require('express');
const router = express.Router();
const { 
    createReviewController,
    getReviewsByRecipeIdController,
    getReviewsByUserController,
    deleteReviewController
} = require('../Controllers/reviews.controller');
const { reviewValidation } = require('../validation/reviews.validators');

// Route for createReview function
router.post('/createReview', reviewValidation, createReviewController);

// Route for getReviewsByRecipe function
router.get('/getReviewsByRecipe/:recipeId', getReviewsByRecipeIdController);

// Route for getReviewsByUser function
router.get('/getReviewsByUser/:username', getReviewsByUserController);

// Route for deleteReview function
router.post('/deleteReview/:reviewId/:recipeId', deleteReviewController);

module.exports = router;
