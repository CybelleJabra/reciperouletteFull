const express = require('express');
const router = express.Router();
const { userProfileController, updateUserBioController, viewUserProfileController } = require('../Controllers/users.controller');

// Route to get current user's profile
router.get('/myProfile', userProfileController);

// Route for viewing another user's profile
router.get('/userProfile/:username', viewUserProfileController);

// Route for updating user bio
router.post('/updateUserBio', updateUserBioController);

module.exports = router; 
 