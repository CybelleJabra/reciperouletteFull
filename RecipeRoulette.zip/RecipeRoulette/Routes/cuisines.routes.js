const express = require('express');
const router = express.Router();
const {
    getCuisinesController,
    getCuisineIdByNameController
} = require('../Controllers/cuisines.controller');

// Route to get a cuisine ID by its name
router.post('/cuisineId', getCuisineIdByNameController);

// Route to render filterpage.ejs
router.get('/filterpage', getCuisinesController);

module.exports = router;
