const express = require('express');
const router = express.Router();
const { registerUserController, loginUserController } = require('../Controllers/login.controller');
const { loginValidation } = require('../validation/login.validators');

// Render login page
router.get('/login', (req, res) => {
    res.render('login');
});

// Render register page
router.get('/register', (req, res) => {
    res.render('register');
})

// Route for register function
router.post('/register', loginValidation, registerUserController);

// Route for login function
router.post('/login', loginUserController);

module.exports = router;
