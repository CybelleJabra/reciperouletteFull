// In spinTheWheel.controller.js
const SpinService = require("../Services/spinTheWheel.services");

// controllers to spin the wheel
const spinTheWheelController = async (req, res) => {

    // get the needed information from req body
    const { dietaryPreferences, calories, cuisineId } = req.body;

    try {
        // calling service spinTheWheel
        const randomRecipe = await SpinService.spinTheWheel(dietaryPreferences, calories, cuisineId);

        // if no recipe found
        if (!randomRecipe) {
            console.log("No recipe found, sending failure response.");
            return res.status(404).json({ success: false, message: "No Recipe Found By These Requirements at This Time" });
        }

        const recipeId = randomRecipe.RecipeID; // Access the RecipeID property
        res.json({ success: true, message: "Recipe Found!", recipeId });
    } catch (error) {
        console.error("Error spinning the wheel:", error);
        res.status(500).json({ success: false, message: "Error spinning the wheel: " + error.message });
    }
}

module.exports = { spinTheWheelController };
