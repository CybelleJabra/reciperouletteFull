const { 
    createRecipe, 
    getRecipesByCriteria, 
    getRecipesByUser,
    getRecipeDetails,
    searchRecipes
} = require('../services/recipes.services');
// requiring the services needed
const { getCuisineIdByName, getCuisineNameById } = require('../services/cuisines.services');
const { getUserIdByUsername, getUsernameByUserId } = require('../services/users.services');
const { getPixabayImages } = require('../External API/recipeImage'); 

// Controller to handle the creation of recipes
const createRecipeController = async (req, res) => {
    // receives recipeData from req body
    const recipeData = req.body;

    try {
        // gets the cuisineId from service getCuisineIdByName
        const cuisineId = await getCuisineIdByName(recipeData.cuisineName);

        // gets the username from the user currently in session
        const username = req.session.user.username;
        // gets the userId
        const userId = await getUserIdByUsername(username);
        
        // checks if cuisineId and userId exist
        if (!cuisineId || !userId) {
            // if they don't, errorPage is rendered to show error
            return res.status(400).render('errorPage', { error: 'Invalid cuisine name or username' });
        }

        // updates the recipe data with the cuisineId and userId
        const newRecipeData = {
            ...recipeData,
            cuisineID: cuisineId,
            userID: userId
        };

        // sends recipe data to service to create recipe
        const result = await createRecipe(newRecipeData);

        // renders recipeCreationSuccess to show success
        res.render('recipeCreationSuccess', { message: "Recipe created successfully!", recipe: result });
    } catch (error) {

        // renders recipeCreationFailure to show failure
        res.render('recipeCreationFailure', { error: error.message });
    }
};

// Controller for retrieving recipes based on multiple criteria
const getRecipesByCriteriaController = async (req, res) => {
    const { dietaryPreferences, calorieLimitPerMeal, preferredCuisine } = req.body;
    try {

        // sends the parameters to service getRecipesByCriteria
        const recipes = await getRecipesByCriteria(dietaryPreferences, calorieLimitPerMeal, preferredCuisine);

        // renders a list of recipes for later use
        res.render('recipesList', { title: "Recipes by Criteria", recipes: recipes });
    } catch (error) {

        // renders errorPage in case of error
        res.render('errorPage', { error: error.message });
    }
};

// Controller for retrieving recipes by user
const getRecipesByUserController = async (req, res) => {
    const { username } = req.params;
    try {
        
        // sends username to service getRecipesByUser
        const recipes = await getRecipesByUser(username);

        // renders list of recipes for later use
        res.render('recipesList', { title: "Recipes by User", recipes: recipes });
    } catch (error) {

        // renders errorPage in case of error
        res.render('errorPage', { error: error.message });
    }
};

// Controller to get recipe details
const getRecipeDetailsController = async (req, res) => {
    const recipeId = req.query.recipeId;  // Get recipeId from the query

    try {
        const recipe = await getRecipeDetails(recipeId);  // Retrieve recipe details
        if (!recipe) {
            return res.status(404).render('errorPage', { error: "Recipe not found" });  // Handle no recipe found
        }

        // Retrieve the cuisine name
        const cuisineName = await getCuisineNameById(recipe.CuisineID);
        recipe.cuisineName = cuisineName;

        // Retrieve the image URL
        const imageUrl = await getPixabayImages(recipe.Title);
        recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';

        // Retrieve the username if userID is not null
        if (recipe.UserID) {
            const username = await getUsernameByUserId(recipe.UserID);
            recipe.Username = username;
        } else {
            recipe.Username = "Recipe Roulette";
        }

        // Render the recipe details page
        res.render('recipedetails', {
            recipe: recipe,
            pageTitle: recipe.Title,
            imageUrl: recipe.imageUrl,
            Username : recipe.Username
        });
    } catch (error) {
        console.error("Error fetching recipe details:", error);
        res.status(500).render('errorPage', { error: "Error fetching recipe details" });
    }
};

// Controller for searching recipes
const searchRecipesController = async (req, res) => {
    const { searchQuery } = req.query;

    try {
        // gets recipes by using service searchRecipes (sends the query)
        const recipes = await searchRecipes(searchQuery);

        // Fetch additional details for each recipe
        for (let recipe of recipes) {
            const cuisineName = await getCuisineNameById(recipe.CuisineID);
            const imageUrl = await getPixabayImages(recipe.Title);

            const RecipeId = recipe.RecipeId;

            recipe.cuisineName = cuisineName;
            recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';
            
        }

        // renders results page with the recipes found
        res.render('results', { title: "Search Results", recipes: recipes });
    } catch (error) {

        // renders errorPage in case of error
        res.render('errorPage', { error: error.message });
    }
};


module.exports = {
    createRecipeController,
    getRecipesByCriteriaController,
    getRecipesByUserController,
    getRecipeDetailsController,
    searchRecipesController
};
