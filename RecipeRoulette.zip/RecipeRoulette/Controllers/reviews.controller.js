const { createReview, getReviewsByRecipeId, getReviewsByUser, updateAverageRating, deleteReview } = require("../services/reviews.services");
const { getUserIdByUsername } = require("../services/users.services");
const moment = require('moment');

// Controller for creating a review
const createReviewController = async (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login'); // Redirect to login if no user in session (session timed out)
    }

    try {

        // get reviewData from req body
        const reviewData = req.body;

        // get username from session
        const username = req.session.user.username;

        // check existence of username
        if (!username) {
            return res.status(400).json({ error: "Username not found in session" });
        }

        // get the userID
        reviewData.userID = await getUserIdByUsername(username);

        // initialize the reviewData as the current data
        reviewData.reviewDate = new Date();

        const result = await createReview(reviewData);
        await updateAverageRating(reviewData.recipeID); // Update average rating after adding a review

        res.redirect(`/getReviewsByRecipe/${reviewData.recipeID}`); // Redirect to the reviews page
    } catch (error) {
        console.error("Error creating review:", error);
        res.status(400).json({ error: error.message });
    }
};

// Controller for getting reviews by recipe ID
const getReviewsByRecipeIdController = async (req, res) => {

    const { recipeId } = req.params; // get recipeId from the req params

    try {
        // get all reviews by recipeId
        const reviews = await getReviewsByRecipeId(recipeId);

        // format the date for each review to DD/MM/YY
        reviews.forEach(review => {
            review.formattedDate = moment(review.reviewDate).format('DD/MM/YY');
        });

        // renders reviews page with the needed information
        res.render('reviews', {
            reviews,
            recipeId
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Controller for getting reviews by user ID
const getReviewsByUserController = async (req, res) => {

    const { username } = req.params; // get username from req params

    try {
        // get all reviews by that user (search by username)
        const reviews = await getReviewsByUser(username);

        // format the date for each review to DD/MM/YY
        reviews.forEach(review => {
            review.formattedDate = moment(review.reviewDate).format('DD/MM/YY');
        });

        // render the reviews page with the found reviews
        res.render('reviews', {
            reviews,
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Controller for deleting a review
const deleteReviewController = async (req, res) => {

    const { reviewId, recipeId } = req.params; // get reviewId and recipeId from req params
    
    try {
        // delete the review with that reviewId
        await deleteReview(reviewId);
        
        await updateAverageRating(recipeId); // Update average rating after deleting a review
        res.status(200).json({ message: "Review deleted successfully" });
    } catch (error) {
        console.error("Error deleting review:", error);
        res.status(400).json({ error: error.message });
    }
};

module.exports = {
    createReviewController,
    getReviewsByRecipeIdController,
    getReviewsByUserController,
    deleteReviewController  
};
