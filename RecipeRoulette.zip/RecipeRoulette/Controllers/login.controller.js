const { registerUser, loginUser } = require("../services/login.services");
const { validationResult } = require('express-validator');

// controller to handle registering users
async function registerUserController(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    // takes username, password, confirmPassword, email as params
    const { username, password, confirmPassword, email } = req.body;

    try {
        // calls service to register user with the above params
        const userId = await registerUser(username, password, confirmPassword, email);
        // renders page registerSuccess to show success
        res.render('registerSuccess', { message: "User registered successfully!" });
    } catch (error) {
        console.error("Error registering user: ", error);
        // renders page registerFailure to show failure
        res.render('registerFailure', { message: "Error registering user" });
    }
}

async function loginUserController(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { username, password } = req.body;

    try {
        // if login successful, saves the username as the user currently in session for later use
        req.session.user = {
            username: username
        };
        console.log(req.session.user);
        // renders page loginSuccess to show success
        res.render('loginSuccess', { message: "Login successful!" });
    } catch (error) {
        console.error("Error logging in: ", error);
        // renders page loginFailure to show failure
        res.render('loginFailure', { message: "Error logging in" });
    }
}

module.exports = {
    registerUserController,
    loginUserController
};
