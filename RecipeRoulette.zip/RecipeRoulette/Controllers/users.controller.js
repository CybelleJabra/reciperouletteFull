const UserService = require("../services/users.services");
const RecipeService = require('../services/recipes.services'); 
const ReviewService = require('../services/reviews.services');  
const { getPixabayImages } = require('../External API/recipeImage'); 
const moment = require('moment'); 

// Function to load the logged-in user's profile
const userProfileController = async (req, res) => {
    if (req.session.user) {
        try {

            // gets the user's recipes, reviews, joinDate, bio using services and sending the username in session
            const recipes = await RecipeService.getRecipesByUser(req.session.user.username);
            const reviews = await ReviewService.getReviewsByUser(req.session.user.username);
            const joinDate = await UserService.getUserJoinDate(req.session.user.username);
            const bio = await UserService.getUserBio(req.session.user.username);

            // formats the date
            const formattedJoinDate = moment(joinDate).format('DD/MM/YY');

            // Fetch additional details for each recipe
            for (let recipe of recipes) {
                const imageUrl = await getPixabayImages(recipe.Title);
                recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';
                recipe.recipeId = recipe.RecipeID;
            }

            // Fetch additional details for each review
            for (let review of reviews) {
                const reviewedRecipe = await RecipeService.getRecipeDetails(review.RecipeID);
                review.recipeTitle = reviewedRecipe.Title;
                review.recipeId = reviewedRecipe.RecipeID;
                review.imageUrl = await getPixabayImages(review.recipeTitle) || '/path/to/default/image.jpg';
                review.ratingImage = `/images/${review.value}star.png`; 
            }

            // renders myProfile page with the necessary information
            res.render('myProfile', {
                joinDate: formattedJoinDate,
                username: req.session.user.username,
                bio: bio,
                recipes: recipes,
                reviews: reviews
            });
        } catch (error) {
            console.error("Error loading profile:", error);
            res.status(500).send("Error loading profile");
        }
    } else {
        // if no user in session, redirects to login page
        res.redirect('/login');
    }
}

// Function to load another user's profile
const viewUserProfileController = async (req, res) => {

    // retrieves username from req params
    const { username } = req.params;

    try {

        // gets the user's recipes, reviews, joinDate and bio using the services (sending username)
        const recipes = await RecipeService.getRecipesByUser(username);
        const reviews = await ReviewService.getReviewsByUser(username);
        const joinDate = await UserService.getUserJoinDate(username);
        const bio = await UserService.getUserBio(username);

        // formats the date
        const formattedJoinDate = moment(joinDate).format('DD/MM/YY');

        // Fetch additional details for each recipe
        for (let recipe of recipes) {
            const imageUrl = await getPixabayImages(recipe.Title);
            recipe.imageUrl = imageUrl || '/path/to/default/image.jpg';
            recipe.recipeId = recipe.RecipeID;
        }

        // Fetch additional details for each review
        for (let review of reviews) {
            const reviewedRecipe = await RecipeService.getRecipeDetails(review.RecipeID);
            review.recipeTitle = reviewedRecipe.Title;
            review.recipeId = reviewedRecipe.RecipeID;
            review.imageUrl = await getPixabayImages(review.recipeTitle) || '/path/to/default/image.jpg';
            review.reviewId = review.ReviewID;
        }

        // renders userProfile page by sending necessary information
        res.render('userProfile', {
            joinDate: formattedJoinDate,
            username: username,
            bio: bio,
            recipes: recipes,
            reviews: reviews
        });
    } catch (error) {
        console.error("Error loading user profile:", error);
        res.status(500).send("Error loading user profile");
    }
}

// controller for updateUserBio service to receive and handle requests
const updateUserBioController = async (req, res) => {
    const { username, newBio } = req.body;

    try {
        // updates the user bio with the newBio
        const result = await UserService.updateUserBio(username, newBio);

        // redirects to myProfile as refreshed
        res.redirect('/myProfile');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

module.exports = {
    userProfileController,
    updateUserBioController,
    viewUserProfileController
};
