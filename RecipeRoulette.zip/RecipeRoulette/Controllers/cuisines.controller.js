const { getCuisines, getCuisineIdByName } = require("../Services/cuisines.services");

// controller for the getCuisines service to receive and handle requests
const getCuisinesController = async (req, res) => {
    try {
        const cuisines = await getCuisines();
        // renders the recevied cuisines to the filterpage to be used
        res.render('filterpage', { cuisines });
    } catch (error) {
        res.status(500).send("Error fetching cuisines");
    }
};
 
/// Controller to fetch cuisine ID by name
const getCuisineIdByNameController = async (req, res) => {
    const { cuisineName } = req.body; // Get the cuisine name from the request body

    try {
        // get the cuisineId using getCuisineIdByName
        const cuisineId = await getCuisineIdByName(cuisineName);
        if (cuisineId) {
            // returns the cuisineId
            res.json({ cuisineId: cuisineId });
        } else {
            res.status(404).send("Cuisine not found");
        }
    } catch (error) {
        res.status(500).render('error', { message: `Error fetching cuisine ID: ${error.message}` });
    }
};


module.exports = {
    getCuisinesController,
    getCuisineIdByNameController
};
