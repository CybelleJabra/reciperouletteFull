const { check } = require('express-validator');

// needed validators for review services
const reviewValidation = [
    check('content')
        .notEmpty().withMessage('Review content is required'),
    check('recipeID')
        .notEmpty().withMessage('Recipe ID is required')
        .isInt({ min: 1 }).withMessage('Invalid recipe ID'),
    check('userID')
        .notEmpty().withMessage('User ID is required')
        .isInt({ min: 1 }).withMessage('Invalid user ID'),
    check('value')
        .isIn([1, 2, 3, 4, 5]).withMessage('Rating value must be either 1, 2, 3, 4, or 5')
        .isInt().withMessage('Rating value must be an integer'),
];
// exports the functions
module.exports = {
    reviewValidation,
};