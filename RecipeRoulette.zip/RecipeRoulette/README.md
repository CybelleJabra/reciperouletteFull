BackEnd:

1. Project Setup Instructions: to setup the project locally
First, you must have Node.js (version 12 or higher) and npm (Node Package Manager)
Then use this command to clone to the repository: git clone <https://github.com/cybellejabra217/reciperoulette.git>
Navigate to project directory: cd reciperoulette
Create the necessary .env file to properly configure the database
Then: npm install and npm install -g nodemon
And finally: "npm/nodemon app" to run the server on port 3001
Prefer to use nodemon app since it just restarts when something is changed in the code or if it reaches an error, it doesn't need to be run again like npm app

2. API Endpoints and Usage: 

 GET/getCuisines: to retrieve all cuisines in database

 POST/register: to register a user with his inputted credentials into the database
 POST/login: to login a user

 POST/createRecipe : to create a recipe and put it in the database
 GET/getRecipesByCuisine/:cuisineName : to retrieve all recipes belonging to a specific cuisineName
 GET/getRecipesByIngredients/:ingredientName : to retrieve all recipes that include a specific ingredient
 GET/getRecipesByDietaryPreferences/:dietaryPreferences : to retrieve all recipes with a dietary preference
 GET/getPicturesByRecipe/:recipeId : to retrieve the pictures that belong to a specific recipeID
 GET/getRecipesByCriteria : to retrieve all recipes from database with that specific criteria

 POST/createReview : to create a review and put it in the database
 GET/getReviewsByRecipe/:recipeId : to retrieve all reviews that belong to a specific recipeID
 GET/getReviewsByUser/:userId  : to retrieve all reviews that belong to a specific userID
 GET/spinTheWheel : to retrieve a random recipe that fits the criteria of the user
 POST/updateUserBio : to update the bio of a specific user


3. Database Schema Description:
My database (RecipeRoulette) has four entities: User, Recipe, Review, Cuisine.

The User entity has attributes: UserID (auto increments), Username, Password, Email, JoinDate (set to current date as soon as user registers), Bio (for the user to give a description of his likings). It is a basic entity that is needed in any database.

The Recipe entity has attributes: RecipeID (auto increments), title, description, ingredients, instructions, difficultylevel, averagerating, cuisineID, calories, userID, dietaryPreferences, recipePictures.
The cuisineID and userID are foreign keys. CuisineID indicates which cuisine the recipe belongs to and the UserID indicates which user created the recipe(NULL if created by system). Title, description, ingredients, calories, and instructions are to allow full details for the recipe. DifficultyLevel and dietaryPreferences are enum, respectively: Easy, Moderate, Hard and Vegan, Vegetarian, Pescetarian, Gluten-Free, Lactose-Intolerant. recipePictures is a blob to allow image files for each recipe for better description. Finally, averageRating is calculated according to the average of the ratings of each recipe.

The Review entity has attributes: ReviewID (auto increments), content, reviewDate, value (of rating), recipeID, userID. The content is a text for a user to describe what he liked or didn't like about the recipe. value must be over 5 to rate the recipe. reviewDate is set as current time once the review is submitted. RecipeID and userID are foreign keys, recipeID indicates to which recipe the review belongs to and the userID indicates which user submitted the review.

The Cuisine entity has attributes: cuisineID(auto increments), cuisineName. The sole purpose of this entity is to provide better normalization for the database.

The rating and review entities used to exist as separate entities, but after logically thinking about the project, I made them into one (deleted rating entity and added "value" for rating into review). 
The overall schema shows a database for recipes with specific cuisine. Users can review or even add their own recipe. The ultimate goal is they can spin a metaphoric "wheel" to get a random recipe based on their preferences. 

4. Third-Party libraries used: 
Express-Validator: to import the validation and check for errors for each function and input
Dotenv: To configure the database
MySQL2: to be able to import my database from mySQL workbench
Express: to define the routes
BCrypt: to hash the passwords
Moment: to get the specific time for joinDate and reviewDate
Multer: To upload, save and validate files (specifically here image files) (no longer used due to the external API)

5. Testing application on postman:
First, you must download postman online and create an account (be sure to have a stable connection)
Click on : Send an API request
Type this: http://localhost:3001
Then to check for a specific route we write the name of the route after the above text
Example: http://localhost:3001/register
Set the request to post (or get, specific for each route)
Set the body to raw
Write this body: 
{
    "username": "exampleUser",
    "password": "examplePassword",
    "confirmPassword": "examplePassword",
    "email": "exampleEmail@live.com"
}

and click on send
This can work for any route with a post request, just put each attribute in double quotations, and write what you want to enter into the database

Another example for some get routes in my database:
http://localhost:3001/getReviewsByRecipe/1
Here we send a get request to retrieve all reviews belonging to recipeID = 1

-------------------------------------------------------------------------------------------------------------------


FrontEnd:

1. Project Setup:
first, download the project using this command: git clone <https://github.com/CybelleJabra/reciperouletteFull.git>
run the project using nodemon app, then open any browser like chrome and type in: 
http://localhost:3001/login

This will take you to the login page where you can signup or login if you already have an account, then you can navigate to every page throughout the website.

2. API Endpoints for rendering pages:

GET/filterpage : renders the filter page
GET/register : renders the register (sign up) page
GET/login : renders the login page
GET/recipedetails : renders the recipe details page of a certain recipe
GET/homepage : renders the home page
GET/taketoresults : renders the take to results page after spinning the wheel
GET/myProfile : renders the profile page of the user currently in session
GET/userProfile/:username : renders a user's profile according to the username sent

Other pages are rendered directly in the controller for logical reasons

3. Third-Party libraries used:

axios: handles HTTP requests for external API (retrieving images online)
express-session : to save the user that logged in as current user in the session
EJS (embedded javascript templates): allows embedding of javascript into HTML (server-side rendering of HTML)

4. Project outline:

Controllers: slightly modified from backend to be able to render information and pages
Routes: added a few more routes to be able to render pages
Services: functions for SQL queries
Validation: validators for different entities
External API: defines the function getPixabayImages that retrieves images from pixabay
Public: includes the style.css and images needed for the styling of the frontend
Views: includes the ejs files for each view in the frontend

5. Views:

-login: the user will start in this page, he can go to register by clicking Sign up if he doesn't have an account
-loginFailure: a page showing failure to login (wrong or nonexisting credentials)
-loginSuccess: a page showing success to login (button Continue to Homepage takes user to homepage)

-register: the user can get here through login to create an account (username, password, email)
-registerFailure: a page showing failure to register (user already exists or password/confirmPassword don't match)
-registerSuccess: a page showing success to register (will be redirected to login to reenter his new credentials)

-homepage: first page user will see after logging in, includes search function where user can write any ingredient,
recipe title (no need in full), cuisine, dietary preference and pressing on search will take the user to results page

-results: showcases all the recipes found according to what the user searched for, pressing on a recipe's title will take the user to its recipe details page

-filterpage: pressing on filter in the top navigation bar takes user to this page, he can choose only one dietary preference, then one cuisine from a choice box, and finally enter maximum calories in a text box. Pressing on "Spin The Wheel" takes user to spinningwheel.

-spinningwheel: a waiting page while the server fetches a random recipe according to what the user inputted in the filterpage, continues to taketoresults page

-taketoresults: shows if a recipe was found or not, if it is found, user presses on "Take me to recipe" and goes to the recipe details of the recipe found. Otherwise, presses on "Back to filter" and goes back to filterpage.

-recipedetails: user can be redirected here through many ways, it shows the title, image, description, ingredients,
instructions, calories, cuisine, average rating and user that created it. A section Created By: will show the username that created it (Recipe Roulette if created through database), clicking on it takes the user to that user's profile. There is a button Check Reviews that takes user to reviews page of that recipe.

-reviews: shows the reviews submitted for that recipe: username (which is clickable to take user to that user's profile), content, date submitted, and rating. There is an option to Add Review (a modal showing content box and rating choice box).

-myprofile: shows the profile of the user currently in session, shows their username, join date, and bio. There is an option to edit bio (a modal pops up) and an option to add recipe (a modal pops up). The reviews and recipes that the user has submitted will be showed there. Also, a user can delete reviews he has submitted. Clicking on the recipe title under reviews or recipes will take user to that recipe's recipe details page
-recipeCreationFailure: when a user fails to properly create a recipe, this page will show up.
-recipeCreationSuccess: when a user succeeds in creating a recipe, this page will show up.

-userprofile: shows the exact same information as myprofile but for other users, no option to edit bio, add recipe, or delete review since it isn't their own profile they are seeing. 

-errorPage: page showing errors, made for simple debugging




