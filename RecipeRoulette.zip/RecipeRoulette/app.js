const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
require("dotenv").config();

const app = express();

// Configure session middleware
app.use(session({
    secret: 'cybelle123',  // secret key for security
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Set to true if using https
}));

// Middleware to parse json bodies
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('Public'));

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Importing the routes (handlers)
const userRoutes = require('./Routes/users.routes');
const recipeRoutes = require('./Routes/recipes.routes');
const cuisineRoutes = require('./Routes/cuisines.routes');
const loginRoutes = require('./Routes/login.routes');
const reviewRoutes = require('./Routes/reviews.routes');
const spinTheWheelRoutes = require('./Routes/spinTheWheel.routes');

// Register and use route handlers
app.use(userRoutes);
app.use(recipeRoutes);
app.use(cuisineRoutes);
app.use(loginRoutes);
app.use(reviewRoutes);
app.use(spinTheWheelRoutes);

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

// Setting up the server to run on the specified port
const port = process.env.PORT || 3001;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
