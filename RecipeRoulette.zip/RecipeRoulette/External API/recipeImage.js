const axios = require('axios');

// external api service to get images from pixabay using an apiKey (uses the recipe's title to get images)
const getPixabayImages = async (query) => {
  const apiKey = '43955200-5a24d9cb7bbebf682d3f5634a';
  const url = `https://pixabay.com/api/?key=${apiKey}&q=${encodeURIComponent(query)}&image_type=photo`;

  try {
    const response = await axios.get(url);
    if (response.data.hits.length > 0) {
      return response.data.hits[0].webformatURL; // Return the first image's URL
    } else {
      return null; // Return null if no images are found
    }
  } catch (error) {
    console.error('Error fetching images from Pixabay:', error.message);
    throw error;
  }
};

module.exports = {
  getPixabayImages,
};
