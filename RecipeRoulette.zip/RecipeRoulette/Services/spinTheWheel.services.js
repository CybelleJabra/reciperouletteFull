// In spinTheWheel.services.js
const RecipeService = require('./recipes.services');

// service to spin the wheel
const spinTheWheel = async (dietaryPreferences, calorieLimitPerMeal, preferredCuisine) => {
    try {

        // simply calls the recipe service: getRecipesByCriteria
        const recipes = await RecipeService.getRecipesByCriteria(dietaryPreferences, calorieLimitPerMeal, preferredCuisine);
        console.log(`Fetched ${recipes.length} recipes`);

        if (recipes.length === 0) {
            console.log("No recipes found.");
            return null;
        }

        // randomly chooses index from list of recipes for one random recipe
        const randomIndex = Math.floor(Math.random() * recipes.length);
        const randomRecipe = recipes[randomIndex];
        console.log(`Selected Recipe: ${randomRecipe.RecipeID}`); 

        return randomRecipe;
    } catch (error) {
        console.error('Error during the spinning wheel process:', error);
        throw new Error('Error spinning the wheel');
    }
}

module.exports = { spinTheWheel };
