const { query } = require('../Database/database');

// Service to create review
const createReview = async (reviewData) => {
    try {
        // query to insert into review the required params
        let sql = `INSERT INTO review (content, reviewDate, recipeID, userID, value) VALUES (?, ?, ?, ?, ?)`;

        // retrieving values from reviewData received
        const values = [
            reviewData.content,
            reviewData.reviewDate || new Date(),
            reviewData.recipeID,
            reviewData.userID,  
            reviewData.value
        ];
        const result = await query(sql, values);
        return { review_id: result.insertId };
    } catch (error) {
        throw new Error(error);
    }
}

// Service to get reviews by recipe ID
const getReviewsByRecipeId = async (recipeId) => {
    try {
        // query to get all reviews by a certain recipeId
        let sql = `SELECT review.*, user.username FROM review JOIN user ON review.userID = user.userID WHERE review.recipeID = ?`;
        const reviews = await query(sql, [recipeId]);
        return reviews;
    } catch (error) {
        throw new Error(error);
    }
}

// Service to get reviews by user ID
const getReviewsByUser = async (username) => {
    try {

        // query to get all reviews by a user
        let sql = `SELECT review.* FROM review 
                   JOIN user ON review.userID = user.userID 
                   WHERE user.username = ?`;
        const reviews = await query(sql, [username]);
        return reviews;
    } catch (error) {
        throw new Error(error);
    }
};

// Service to update average rating
const updateAverageRating = async (recipeId) => {
    try {

        // query to calculate the average of ratings for recipe
        let sql = `SELECT AVG(value) AS avgRating FROM review WHERE recipeID = ?`;
        const result = await query(sql, [recipeId]);

        let avgRating = result[0].avgRating || 0;
        let updateSql = `UPDATE recipe SET averageRating = ? WHERE recipeID = ?`;
        await query(updateSql, [avgRating, recipeId]);
    } catch (error) {
        throw new Error(error);
    }
}

// Service to delete a review by review ID
const deleteReview = async (reviewId) => {
    try {

        // query to delete review according to reviewId
        let sql = 'DELETE FROM review WHERE reviewID = ?';
        await query(sql, [reviewId]);
    } catch (error) {
        throw new Error(error);
    }
}

module.exports = {
    createReview,
    getReviewsByRecipeId,
    getReviewsByUser,
    updateAverageRating,
    deleteReview  
};
