const pool = require('../Database/database');

// Service to create a recipe
const createRecipe = async (recipeData) => {
    try {
        // sql query to insert into recipe the required params
        let sql = `INSERT INTO recipe (title, description, ingredients, instructions, difficultyLevel, cuisineID, calories, userID, dietaryPreferences) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

        // retrieving the params from the recipeData received
        const values = [
            recipeData.title,
            recipeData.description,
            recipeData.ingredients,
            recipeData.instructions,
            recipeData.difficultyLevel,
            recipeData.cuisineID,
            recipeData.calories,
            recipeData.userID,
            recipeData.dietaryPreferences,
        ];
        const result = await pool.query(sql, values);
        return { recipe_id: result.insertId };
    } catch (error) {
        throw new Error(error);
    }
};

// Service to get recipes by criteria
const getRecipesByCriteria = async (dietaryPreferences, calorieLimitPerMeal, preferredCuisine) => {
    try {

        // query to get all recipes according to the criteria
        let sql = `SELECT * FROM recipe 
                   JOIN cuisine ON recipe.cuisineID = cuisine.cuisineID 
                   WHERE dietaryPreferences = ? 
                   AND calories <= ? 
                   AND cuisine.cuisineId= ?`;
        const values = [dietaryPreferences, calorieLimitPerMeal, preferredCuisine];
        const recipes = await pool.query(sql, values);
        return recipes;
    } catch (error) {
        throw new Error(`Error retrieving recipes by criteria: ${error.message}`);
    }
};

// Service to get recipes by a specific user
const getRecipesByUser = async (username) => {
    try {

        // query to get all recipes by a certain user
        let sql = `SELECT recipe.* FROM recipe 
                   JOIN user ON recipe.userID = user.userID 
                   WHERE user.username = ?`;
        const recipes = await pool.query(sql, [username]);
        return recipes;
    } catch (error) {
        throw new Error(`Error retrieving recipes by user: ${error.message}`);
    }
};

// Service to retrieve detailed information about a specific recipe
const getRecipeDetails = async (recipeId) => {
    try {

        // query to get all recipe details
        const result = await pool.query(`
            SELECT recipe.*, cuisine.cuisineName, user.username
            FROM recipe 
            LEFT JOIN cuisine ON recipe.cuisineID = cuisine.cuisineID
            LEFT JOIN user ON recipe.userID = user.userID
            WHERE recipe.recipeID = ?
        `, [recipeId]);

        if (result.length === 0) {
            throw new Error("Recipe not found");
        }

        return result[0];  // Return the first row (the recipe details)
    } catch (error) {
        console.error('Error retrieving recipe details:', error);
        throw error;
    }
};

// Service to search recipes
const searchRecipes = async (searchQuery) => {
    try {

        // query for search implementation by title, ingredients, cuisine OR dietaryPreferences
        let sql = `
            SELECT recipe.*, cuisine.cuisineName, user.username
            FROM recipe
            LEFT JOIN cuisine ON recipe.cuisineID = cuisine.cuisineID
            LEFT JOIN user ON recipe.userID = user.userID
            WHERE recipe.title LIKE ? 
            OR recipe.ingredients LIKE ? 
            OR recipe.dietaryPreferences LIKE ? 
            OR cuisine.cuisineName LIKE ?
        `;
        const query = `%${searchQuery}%`;
        const recipes = await pool.query(sql, [query, query, query, query]);
        return recipes;
    } catch (error) {
        throw new Error(`Error searching recipes: ${error.message}`);
    }
};

module.exports = {
    createRecipe,
    getRecipesByCriteria,
    getRecipesByUser,
    getRecipeDetails,
    searchRecipes
};
