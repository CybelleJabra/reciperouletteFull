const { query } = require('../Database/database');

// service to get cuisines
const getCuisines = async () => {
    try {
        const sql = `SELECT cuisineName FROM cuisine`; // Changed to fetch only cuisine names
        const result = await query(sql);
        return result.map(cuisine => cuisine.cuisineName); // Map to return only names
    } catch (error) {
        throw new Error('Error fetching cuisines');
    }
};

// service to get cuisine ID by its name
const getCuisineIdByName = async (cuisineName) => {
    try {

        // query to retrieve cuisineId according to cuisineName
        const sql = `SELECT cuisineID FROM cuisine WHERE cuisineName = ?`;

        // requesting query
        const result = await query(sql, [cuisineName]);
        if (result.length) return result[0].cuisineID;
        else return null;
    } catch (error) {
        throw new Error(`Error fetching cuisine ID by name: ${error.message}`);
    }
};

// service to get cuisine name by its id
const getCuisineNameById = async (cuisineId) => {
    try {

        // query to retrieve cuisine name from cuisineId
        let sql = `SELECT cuisineName FROM cuisine WHERE cuisineID = ?`;

        // requesting query
        const [result] = await query(sql, [cuisineId]);
        if (!result) {
            throw new Error("Cuisine not found");
        }
        return result.cuisineName;
    } catch (error) {
        throw new Error(`Error retrieving cuisine name: ${error.message}`);
    }
};

module.exports = {
    getCuisines,
    getCuisineIdByName,
    getCuisineNameById
};
