const { query } = require('../Database/database');

// service to update user bio
const updateUserBio = async (username, newBio) => {
    try {
        // SQL query to update the bio of the user with the specified userID
        let sql = `UPDATE User SET bio = ? WHERE username = ?`;
        const values = [newBio, username];
        await query(sql, values);
        return { username: username };
    } catch (error) {
        throw new Error(error); 
    }
}

// service to get user by username
const getUserByUsername = async (username) => {
    try {
        // SQL query to fetch user details by username
        let sql = `SELECT * FROM user WHERE username = ?`;
        const [user] = await query(sql, [username]);
        if (!user) {
            throw new Error("User not found");
        }
        return user;
    } catch (error) {
        throw new Error(error);
    }
}

// service to get user id by username
const getUserIdByUsername = async (username) => {
    try {

        // sql query to select userId belonging to sent username
        let sql = `SELECT userId FROM user WHERE username = ?`;
        const [user] = await query(sql, [username]);
        if (!user) {
            throw new Error("User not found");
        }
        return user.userId; 
    } catch (error) {
        throw new Error(error);
    }
}

const getUsernameByUserId = async (userId) => {
    try {
        // Define the SQL query to fetch the username by userId
        const sql = `SELECT username FROM user WHERE userId = ?`;

        // Execute the query and destructure the first result
        const [user] = await query(sql, [userId]);
        console.log(userId);

        // Check if a user was found
        if (!user) {
            throw new Error("User not found");
        }

        // Return the username if a user was found
        return user.username;
    } catch (error) {
        // Properly forward the error message
        throw new Error(`Error fetching username: ${error.message}`);
    }
}

// service to get user join date by username
const getUserJoinDate = async (username) => {
    try {
        // SQL query to fetch user join date by username
        let sql = `SELECT joinDate FROM user WHERE username = ?`;
        const [result] = await query(sql, [username]);
        if (!result) {
            throw new Error("User not found");
        }
        return result.joinDate;
    } catch (error) {
        throw new Error(error);
    }
}

// service to get user bio by username
const getUserBio = async (username) => {
    try {
        // SQL query to fetch user bio by username
        let sql = `SELECT bio FROM user WHERE username = ?`;
        const [result] = await query(sql, [username]);
        if (!result) {
            throw new Error("User not found");
        }
        return result.bio;
    } catch (error) {
        throw new Error(error);
    }
}

// exports the functions
module.exports = {
    updateUserBio,
    getUserByUsername,
    getUserJoinDate,
    getUserBio,
    getUserIdByUsername,
    getUsernameByUserId
};
